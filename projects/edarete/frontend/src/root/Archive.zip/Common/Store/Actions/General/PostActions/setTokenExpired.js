import { SET_TOKEN_EXPIRED } from "../../ActionTypes/ApiActionTypes";
export const setTokenExpired = () => {
    return {
        type: SET_TOKEN_EXPIRED,

    }
}