const GETCOURSE ="GETCOURSE";
export default GETCOURSE;