const GETROOM='GETROOM';
export default GETROOM;