import { combineReducers } from "redux";
import mainReducer from "./mainReducer";
import GetUserRedcuer from "./GetUsersReducer/GetUsersReducer";
import GetRoomReducer from "./GetRoomReducer/GetRoomReducer";
import GetTimeTableRedcer from "./GetTimeTableRedcer/GetTimeTableRedcer";
import GetCourseReducer from "./GetCourseReducer/GetCourseReducer";
import GetSemesterReducer from "./GetSemesterReducer/GetSemesterReducer";
import AddTimeTableReducer from "./AddTimeTableReducer/AddTimeTableReducer";
import GetFilterReducer from "./FilterReducer/FilterReducer";
import LoginReducer from "./LoginReducer";

const rootReducer = combineReducers({
  main: mainReducer,
  GETUSERREDUCER: GetUserRedcuer,
  GETROOMREDUCER: GetRoomReducer,
  GETTIMETABLEREDUCER: GetTimeTableRedcer,
  GETCOURSEREDUCER: GetCourseReducer,
  GETRSEMSTERREDUCER: GetSemesterReducer,
  addtimetablereducer:AddTimeTableReducer,
  GETFILTERREDUCER:GetFilterReducer,
  // Auth
  LOGINREDUCER: LoginReducer,
});
export default rootReducer;