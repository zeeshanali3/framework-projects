import  { ACTIVITIES } from "../../Actions/ActionTypes/ApiActionTypes"
import {takeEvery} from "redux-saga/effects";
import fetchData from "../SagaHelper";

export  function * GetActivitiesSaga(){

    yield takeEvery(ACTIVITIES,fetchData);
}