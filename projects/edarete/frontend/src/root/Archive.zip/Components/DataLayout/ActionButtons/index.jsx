import React, { useState, useRef, useEffect } from "react";
import { useSelector } from 'react-redux';
import IconButton from "@mui/material/IconButton";
import Grid from "@mui/material/Grid";
import Grow from "@mui/material/Grow";
import { MoreHoriz } from "@mui/icons-material";
import { Tooltip, useTheme } from "@mui/material";
import DefaultIcon from "@mui/icons-material/Help"; // Default fallback icon
import { getIconComponent } from "../constants/iconsMap";
import ConfirmationModal from "./ConfirmationModal";
import { useSocket } from "../../Socket/index";
import { showSuccessToast ,showErrorToast} from "../../../Common/ToastUtils";
import { constants } from "../../../Common/Constants";

// Default color mapping

export default function ActionButtons({
  color,
  actions,
  displayMode,
  onAction,
  isDarkMode,
  rowData
}) {
  const [showActions, setShowActions] = useState(false);
  const [iconComponents, setIconComponents] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  const containerRef = useRef(null);
  const theme = useTheme();
  const { currentUser, userSelectedRole } = useSelector((state) => state.main);
 const all_state = useSelector((state) => state.main);
 const accessToken = all_state?.accesstoken || null;
  const { connect, disconnect, isConnected, emit } = useSocket( constants.socket_url,accessToken); // Remove hardcoded URL

  // Get current user from Redux


  const handleToggleActions = () => {
    setShowActions((prev) => !prev);
  };
const colorMapping = {
  Edit: "#4A90E2", // blue
  Delete: "#d81717", // red
  View: isDarkMode ? "#fff" : "grey",
  start: "#28a745", // green for start action
};

  const handleAction = (action, data, index) => {
    if (action.name === "Delete") {
      // show confirmation first
      setPendingAction({ action, data, index });
      setConfirmOpen(true);
    } else if (action.name === "start") {
      // Handle socket connection
      console.log('Initiating start action with data:', { action, data, index, isConnected ,});
      handleStartAction(action, data, index, rowData);
    } else {
      onAction?.(action, data, index);
    }
  };

  const handleStartAction = (action, data, index, fullRowData) => {
    console.log('Starting handleStartAction with:', { action, data, isConnected, fullRowData });

    if (isConnected) {
      console.log('Socket already connected, sending start-quiz event');
      // Get current user info from localStorage
      const userInfo = JSON.parse(localStorage.getItem('user_info') || '{}');
      const participant = {
          name: currentUser?.first_name + " " + currentUser?.last_name  || 'Unknown User',
          urdd: userSelectedRole?.user_role_designation_department_id,
          role:userSelectedRole?.role_name
        };

      // Use fullRowData if available, otherwise fallback to rowData prop
      const rowDataToUse = fullRowData || rowData;
      const quizId = rowDataToUse?.id || rowDataToUse?.quizId || rowDataToUse?._id;

      if (!quizId) {
        console.error('Quiz ID not found in row data:', rowDataToUse);
        return;
      }
      console.log("Quiz details are :",{quizId,participant})
      emit('start-quiz', { quizId, participant });
      showSuccessToast('Quiz started successfully!');
      console.log('Emitted start-quiz event:', { quizId, participant });
    } else {
      console.log('Socket not connected, attempting to connect...');
      console.log('Current socket connection status:', { isConnected });

      const socket = connect();
      console.log('Socket instance after connect():', socket);

      if (!socket) {
        console.error('Failed to get socket instance from connect()');
        showErrorToast('Failed to connect to the server. Please try again later.');
        return;
      }

      // Check if socket is already connected
      console.log('Socket connected status after connect():', socket.connected);

      // Emit immediately if already connected
      if (socket.connected) {
        console.log('Socket was already connected, emitting immediately');
        const participant = {
          name: currentUser?.first_name + " " + currentUser?.last_name  || 'Unknown User',
          urdd: userSelectedRole?.user_role_designation_department_id,
          role:userSelectedRole?.role_name
        };
        console.log("Participant info:", participant);
        // Use fullRowData if available, otherwise fallback to rowData prop
        const rowDataToUse = fullRowData || rowData;
        const quizId = rowDataToUse?.id || rowDataToUse?.quizId || rowDataToUse?._id;

        if (!quizId) {
          console.error('Quiz ID not found in row data:', rowDataToUse);
          return;
        } 
        console.log("Quiz details are :",currentUser, userSelectedRole,{quizId,participant})

        emit('start-quiz', { quizId, participant });
        showSuccessToast('Quiz started successfully!');
        console.log('Emitted start-quiz event immediately:', { quizId, participant });
        return;
      }

      // Set up connection handler
      socket.on('connect', () => {
        console.log('Socket connected successfully! ID:', socket.id);
        console.log('Socket connected status:', socket.connected);

        // Get current user info from localStorage

        const participant = {
          name: currentUser?.first_name + " " + currentUser?.last_name  || 'Unknown User',
          urdd: userSelectedRole?.user_role_designation_department_id,
          role:userSelectedRole?.role_name
        };

        // Extract quizId from fullRowData if available, otherwise from rowData prop
        const rowDataToUse = fullRowData || rowData;
        const quizId = rowDataToUse?.id || rowDataToUse?.quizId || rowDataToUse?._id;

        if (!quizId) {
          console.error('Quiz ID not found in row data:', rowDataToUse);
          return;
        }
        console.log("Quiz details are :",currentUser, userSelectedRole,{quizId,participant})
        emit('start-quiz', { quizId, participant });
        showSuccessToast('Quiz started successfully!');
        console.log('Emitted start-quiz event after connection:', { quizId, participant });
      });

      // Handle connection errors
      socket.on('connect_error', (error) => { 
        console.error('Socket connection error:', error);
        showErrorToast('Socket connection error. Please try again later.');

      });

      socket.on('error', (error) => {
        console.error('Socket error:', error);
        showErrorToast('Socket error occurred. Please try again later.');
      });
    }
  };

  const handleConfirm = () => {
    if (pendingAction && onAction) {
      onAction(pendingAction.action, pendingAction.data, pendingAction.index);
    }
    setConfirmOpen(false);
    setPendingAction(null);
  };

  const handleCancel = () => {
    setConfirmOpen(false);
    setPendingAction(null);
  };
  // Close action buttons when clicking outside the container
  const handleClickOutside = (event) => {
    if (containerRef.current && !containerRef.current.contains(event.target)) {
      setShowActions(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Fetch the icons when the component is mounted
  useEffect(() => {
    const fetchIcons = async () => {
      const icons = {};

      if (actions.length > 0) {
        for (const action of actions) {
          const iconComponent = getIconComponent(action.name);
          icons[action.name] = iconComponent;
        }
        setIconComponents(icons);
      }
    };
    fetchIcons();
  }, [actions]);

  return (
    <div ref={containerRef}>
      <Grid container justifyContent="center" alignItems="center">
        {displayMode === "table" ? (
          <Grid container item xs={12} spacing={0} justifyContent="center">
            {actions.map((action, index) => {
              const IconComponent = iconComponents[action?.name] || DefaultIcon;
              const iconColor =
                colorMapping[action?.name] || action?.color || "grey";
              return (
                <Grid item key={index}>
                  <IconButton onClick={() => handleAction(action, index)}>
                    <IconComponent style={{ color: iconColor }} />
                  </IconButton>
                </Grid>
              );
            })}
          </Grid>
        ) : !showActions ? (
          <Grow in={!showActions} timeout={500}>
            <IconButton aria-label="more" onClick={handleToggleActions}>
              <MoreHoriz
                sx={{
                  color: color,
                  "&:hover": {
                    bgcolor: isDarkMode ? "#4F4F5C" : "#DCDCDC",
                    borderRadius: "100%",
                  },
                }}
              />
            </IconButton>
          </Grow>
        ) : (
          <Grid container item xs={12} spacing={0} justifyContent="center" flexWrap="wrap">
            {actions.map((action, index) => {
              const IconComponent = iconComponents[action?.name] || DefaultIcon;
              console.log(`Expanded view - Rendering ${action.name} with icon:`, IconComponent !== DefaultIcon ? 'Custom' : 'Default');
              return (
                <Grid item key={index}>
                  <Grow
                    in={showActions}
                    timeout={1000}
                    style={{ transformOrigin: "center center" }}
                  >
                    <Tooltip title={action?.name} placement="top">
                      <IconButton
                        aria-label={action?.name}
                        size="small"
                        onClick={() => handleAction(action, index)}
                        sx={{
                          background: "#ffffff",
                          ml: "2px",
                          mr: "2px",
                        }}
                      >
                        <IconComponent
                          style={{ color: action?.color || colorMapping[action?.name] || "black" }}
                        />
                      </IconButton>
                    </Tooltip>
                  </Grow>
                </Grid>
              );
            })}
          </Grid>
        )}
      </Grid>
       <ConfirmationModal
        open={confirmOpen}
        title="Confirm Delete"
        description="Are you sure you want to delete this item?"
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    </div>
  );
}