import React, { useState, useRef } from "react";
import { Button } from "@mui/material";
import * as XLSX from "xlsx";
import { FileDownload } from "@mui/icons-material";
import { getServerResponse } from "../../Helpers/getServerResponse";

const ImportFunction = ({
  parameters,
  color,
  speedDial,
  addSagaCommunication,
  onSuccess = (message) => console.log(message),
  onFailure = (error) => console.error(error),
}) => {
  const [file, setFile] = useState(null);
  const fileInputRef = useRef(null); // Create a ref for the file input

  // Handle file input change
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFile(file);
      handleFileImport(file); // Call handleFileImport after file is selected
    }
  };

  // Handle file import and read it
  const handleFileImport = (file) => {
    if (!file) {
      alert("Please select a file first.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (e) => {
      let jsonData = [];

      try {
        if (file.name.endsWith(".csv")) {
          const text = e.target.result;
          const rows = text
            .split("\n")
            .map((row) => row.split(","))
            .filter(
              (row) => row.length > 1 || row.some((cell) => cell.trim() !== "")
            );

          if (rows.length < 2) {
            throw new Error(
              "CSV file does not contain enough data (requires headers and at least one row)."
            );
          }

          jsonData = rows;
        } else if (file.name.endsWith(".xls") || file.name.endsWith(".xlsx")) {
          const workbook = XLSX.read(e.target.result, { type: "binary" });

          if (!workbook.SheetNames?.length) {
            throw new Error("Excel file does not contain any sheets.");
          }

          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];

          jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          if (!Array.isArray(jsonData) || jsonData.length < 2) {
            throw new Error("Excel file is empty or missing data rows.");
          }
        } else {
          alert("Unsupported file format. Please upload a CSV or Excel file.");
          throw new Error(
            "Unsupported file format. Please upload a CSV or Excel file."
          );
        }
      } catch (err) {
        
        onFailure?.(
          err instanceof Error
            ? err
            : new Error("Invalid file format or unreadable file.")
        );
        return;
      }

    

      const parametersList = parameters?.filter((h) => h?.visible !== false);
      if (!parametersList?.length || !parameters?.length) {
        const error = "No data or visible columns to export.";
        onFailure?.(new Error(error));
        return;
      }
      const headers = jsonData[0];
      const rows = jsonData.slice(1);
      // const visibleHeaders = headers?.filter((h) => h?.visible !== false);

      const paramHeaders = parametersList.filter(Boolean).map((param) => ({
        label: param.displayName || param.label || param.name,
        key: param.dynamicKey,
      }));

      // Validate header count
      if (headers.length !== paramHeaders.length) {
        const error = `Expected ${paramHeaders.length} columns, got ${headers.length}`;
        console.error("Header length mismatch:", error);
        onFailure?.(new Error(error));
        return;
      }

      // Validate row lengths
      const invalidRowIndex = rows.findIndex(
        (row) => row.length !== headers.length
      );
      if (invalidRowIndex !== -1) {
        const error = `Row ${
          invalidRowIndex + 2
        } has inconsistent column count.`;
        console.error(error);
        onFailure?.(new Error(error));
        return;
      }
      // Validate that no cell is empty (optional: trim to ignore whitespace)
      const requiredColumns = parametersList.filter((param) => param.required); // if you have a `required` flag

      const emptyRequiredValueRowIndex = rows.findIndex((row) =>
        requiredColumns.some((param) => {
          const colIndex = headers.findIndex(
            (h) =>
              h?.trim()?.toLowerCase() ===
              (param.label || param.name)?.trim()?.toLowerCase()
          );
          return (
            colIndex === -1 ||
            row[colIndex] == null ||
            row[colIndex].toString().trim() === ""
          );
        })
      );

      if (emptyRequiredValueRowIndex !== -1) {
        const spreadsheetRow = emptyRequiredValueRowIndex + 2; // +1 for index, +1 for header
        const entryNumber = emptyRequiredValueRowIndex + 1; // Relative to user-visible data
        const error = `Entry #${entryNumber} (spreadsheet row ${spreadsheetRow}) has missing required field(s). Please complete all required fields.`;
        console.error(error);
        onFailure?.(new Error(error));
        return;
      }

      // Map headers to dynamic keys
      const labelToKeyMap = {};
      paramHeaders.forEach(({ label, key }) => {
        const index = headers.findIndex(
          (h) => h?.trim()?.toLowerCase() === label?.trim()?.toLowerCase()
        );
        if (index !== -1) {
          labelToKeyMap[index] = key;
        }
      });

      // Ensure all expected keys matched
      const matchedKeys = Object.values(labelToKeyMap);
      if (matchedKeys.length !== paramHeaders.length) {
        const missing = paramHeaders
          .filter((h) => !matchedKeys.includes(h.key))
          .map((h) => h.label);
        const error = `Missing expected columns: ${missing.join(", ")}`;
        console.error(error);
        onFailure?.(new Error(error));
        return;
      }

      // Convert to dataObjects
      const dataObjects = rows.map((row) => {
        const obj = {};
        Object.entries(labelToKeyMap).forEach(([colIndex, key]) => {
          obj[key] = row[colIndex]?.toString().trim();
        });
        return obj;
      });

      

      // Handle server communication
      // const updatedPayload = {
      //   ...addSagaCommunication,
      //   body: {
      //     ...(addSagaCommunication.body || {}),
      //     import_users: dataObjects,
      //   },
      // };
      addSagaCommunication.body.list_options = dataObjects;
  
      getServerResponse(addSagaCommunication);
      onSuccess("File imported and data processed successfully!");
    };

    reader.onerror = (error) => {
      console.error("Error reading file:", error);
      onFailure("Failed to read the file.");
    };

    reader.readAsBinaryString(file);
  };

  const processParsedData = (rows) => {
    if (!rows || rows.length < 2) {
      onFailure("Imported file has no valid data.");
      return;
    }

    

    const headers = rows[0];
    const updatedHeaders = headers.map((header) => {
      const param = parameters.find((param) => param.label === header);
      if (!param) console.warn(`Header "${header}" not found in parameters.`);
      return param?.dynamicKey || header;
    });



    const dataObjects = rows.slice(1).map((row) => {
      const obj = {};
      row.forEach((cell, index) => {
        obj[updatedHeaders[index]] = cell;
      });
      return obj;
    });

  

    if (addSagaCommunication) {
      const updatedPayload = {
        ...addSagaCommunication,
        body: {
          ...(addSagaCommunication.body || {}),
          import_users: dataObjects,
        },
      };

      getServerResponse(updatedPayload);
      onSuccess("File imported and data processed successfully!");
    }
  };

  //   const handleFileImport = (file) => {
  //     if (!file) {
  //       alert("Please select a file first.");
  //       return;
  //     }

  //     const reader = new FileReader();

  //     reader.onload = (e) => {
  //       let parsedRows = [];
  //    if (file.name.endsWith(".csv")) {
  //   const text = e.target.result;
  //   const rows = text.split("\n").map(row => row.split(","));
  //   processParsedData(rows);
  // } else {
  //   const workbook = XLSX.read(e.target.result, { type: "binary" });
  //   const sheetName = workbook.SheetNames[0];
  //   const worksheet = workbook.Sheets[sheetName];
  //   const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
  //   processParsedData(jsonData);
  // }

  //       // Log the data (array of arrays)
  //       console.log("Imported Data:", jsonData);

  //       // For now, convert the data into an array of objects for better readability
  //       const headers = jsonData[0]; // First row is the header
  //       const updatedHeaders = headers.map((header) => {
  //         // Find the parameter object where the label matches
  //         const parameter = parameters.find((param) => param.label === header);

  //         if (parameter) {
  //           return parameter.dynamicKey; // Replace with dynamic_key
  //         }
  //         if (!parameter) {
  //           console.warn(`Header "${header}" not found in parameters.`);
  //           return header; // Leave unchanged if no match is found
  //         }
  //       });

  //       console.log("updatedHeaders", updatedHeaders);
  //       const dataObjects = jsonData.slice(1).map((row) => {
  //         const obj = {};
  //         row.forEach((cell, index) => {
  //           obj[updatedHeaders[index]] = cell;
  //         });
  //         return obj;
  //       });

  //       console.log("Converted Data:", dataObjects, addSagaCommunication); // Log data as array of objects
  //       if (addSagaCommunication) {
  //         // If body doesn't exist, just add it directly
  //         if (!addSagaCommunication.hasOwnProperty("body")) {
  //           addSagaCommunication.body = { import_users: dataObjects }; // Add body key with dataObjects as the value
  //           console.log(
  //             "Body added to addSagaCommunication:",
  //             addSagaCommunication
  //           );
  //         } else {
  //           addSagaCommunication.body = { import_users: dataObjects };
  //         }
  //       }
  //       console.log("addSagaCommunication", addSagaCommunication);
  //       getServerResponse(addSagaCommunication);
  //       // Call success function after import
  //       onSuccess("File imported and data processed successfully!");
  //     };

  //     reader.onerror = (error) => {
  //       // Handle error reading file
  //       console.error("Error reading file:", error);
  //       onFailure("Failed to read the file.");
  //     };

  //     reader.readAsBinaryString(file); // Read file as binary string
  //   };

  // Trigger the file input on button click
  const triggerFileInput = () => {
    fileInputRef.current.click(); // Programmatically trigger the file input
  };

  return (
    <>
      <input
        ref={fileInputRef} // Set the ref on the input field
        accept=".xlsx, .xls, .csv"
        type="file"
        onChange={handleFileChange} // Now the file input change will call handleFileChange
        style={{ marginBottom: 10, display: "none" }} // Keep hidden
      />
      <Button
        onClick={triggerFileInput} // Trigger file input
        sx={{
          width: "100%",
          alignItems: "center",
          justifyContent: "center",
          color: color,
          gap: speedDial ? 1 : 0,
          "&:hover": {
            backgroundColor: "transparent",
            color: color,
          },
        }}
      >
        {speedDial && "Import"} <FileDownload sx={{ fontSize: 20 }} />
      </Button>
    </>
  );
};

export default ImportFunction;
