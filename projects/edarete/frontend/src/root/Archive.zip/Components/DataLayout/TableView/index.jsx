import React, {
  useEffect,
  useState,
  useCallback,
  useRef,
} from "react";
import { DataGrid } from "@mui/x-data-grid";
import {
  Typography,
  AvatarGroup,
  Avatar,
  Box,
  Menu,
  MenuItem,
  Button,
  IconButton,
  Tooltip,
  Fade,
  Grow,
  Select,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import ActionButtons from "../ActionButtons";
import { HasPermission } from "../constants/permissionChecker";
import { useSelector } from "react-redux";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import VisibilityIcon from "@mui/icons-material/Visibility";
import WysiwygOutlinedIcon from "@mui/icons-material/WysiwygOutlined";
import ArrowRightRoundedIcon from "@mui/icons-material/ArrowRightRounded";
import ReactDOM from "react-dom";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Sort, ArrowUpward, ArrowDownward } from "@mui/icons-material";
import SortByAlphaRoundedIcon from "@mui/icons-material/SortByAlphaRounded";
import { showWarningToast } from "../../../Common/ToastUtils";

import TableSkeleton from "../TableSkeleton";
function EditableStatusCell({
  value,
  statusOptions,
  statusColors,
  onChange,
  onBlur,
}) {
  const [open, setOpen] = useState(true); // open immediately
  const selectRef = useRef(null);

  useEffect(() => {
    setOpen(true); // open on mount
    if (selectRef.current) {
      selectRef.current.focus();
    }
  }, []);
  // Handler for closing the dropdown
  const handleClose = () => {
    setOpen(false);
    if (onBlur) onBlur(); // Exit edit mode in parent
  };

  return (
    <Select
      ref={selectRef}
      value={value}
      onChange={onChange}
      onBlur={onBlur}
      open={open}
      onClose={handleClose}
      onOpen={() => setOpen(true)}
      autoFocus
      sx={{
        padding: "4px 8px",
        borderRadius: ".7rem",
        // border: "1px solid #ccc",
        // background: statusColors[value]?.background,
        background: "white",
        color: statusColors[value]?.color,
        fontWeight: 500,
        // minWidth: 80,
        // minHeight: 150,
        boxShadow: "none", // Remove focus shadow
        "&.Mui-focused": {
          background: statusColors[value]?.background,
          color: statusColors[value]?.color,
          // border: "1px solid red",
        },
        "& .MuiSelect-select": {
          padding: "4px 8px",
        },
        "&:focus": {
          outline: "none",
        },
      }}
      MenuProps={{
        PaperProps: {
          style: {
            // background: statusColors[value]?.background,
            background: "white",
            minHeight: 80,
            alignContent: "center",
            // color: statusColors[value]?.color,
            color: "white",
          },
        },
      }}
    >
      {statusOptions.map((opt) => (
        <MenuItem
          key={opt.value || opt.label || opt}
          value={opt.value}
          style={{
            // background: statusColors[opt.value]?.background,
            width: "80px",
            height: "25px",
            margin: ".4rem",
            // borderRadius: ".8rem",
            // marginTop: ".5rem",
            // background: "transparent",
            // color: statusColors[opt.value]?.color,
            color: "#8d5795",
            // transition: "background 0.2s, color 0.2s, font-weight 0.2s",
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.background = "#E0E3EB";
            // e.currentTarget.style.fontWeight = "bold";
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.background = "transparent";
            e.currentTarget.style.fontWeight = "normal";
          }}
        >
          {opt.label}
        </MenuItem>
      ))}
    </Select>
  );
}

const TableView = ({
  appearanceProp,
  configProp,
  dataProp,
  additionalProp,
  onRowAction,
  onUpdateRefreshData,
  isDarkMode,
  textColor,
  secondaryTextColor,
  themeStyles,
  showSearchIcon,
  externalMenuAnchorEl,
  onExternalMenuOpen,
  onExternalMenuClose,
  isMenuExternallyControlled = false,
  userStatusUpdationPermission,
  useDragAndDropFeature = true,
  enableRowActions = true,
  enableUserStatusUpdation = true,
  enableCollapsibleRow = true,
  // New props for dynamic row-specific actions
  rowActionsConfig = null, // Configuration for row-specific actions
}) => {
  const { currentUserPermissions } = useSelector((state) => state.main);
  const theme = useTheme();
  //.log("TableView themeStyles:", additionalProp);
  // const isLoading =
  //   !Array.isArray(additionalProp?.data) ||
  //   additionalProp.data.length === 0 ||
  //   !Array.isArray(dataProp?.features?.parameters?.fields) ||
  //   dataProp.features.parameters.fields.length === 0;
  // Get correct colors from theme styles or fallback
  const headerBgColor =
    themeStyles?.header?.headColor || (isDarkMode ? "#2d2d3d" : "#f0f0f0");
  const headerTextColor =
    themeStyles?.header?.headTextColor || (isDarkMode ? "#ffffff" : "#000000");
  const borderColor =
    themeStyles?.image?.borderColor || (isDarkMode ? "#6C63FF" : "#7479ed");
  const actionButtonColor =
    themeStyles?.actionButtons?.color || (isDarkMode ? "#a5a4c4" : "#7b7a8c");
  // const lightTable = appearanceProp?.light?.table;
  const lightTable = theme?.customTokens?.light.table;

  const darkTable = theme?.customTokens?.dark.table;

  const rowActionsIsServerDriven =
    configProp?.features?.rowActions?.operationalMode == "server"
      ? true
      : false;
  const { bulkActionArray, setbulkActionArray } =
    additionalProp?.bulkActions || {};
  const [checkboxEnabled, setCheckboxEnabled] = useState(
    configProp?.grid?.checkBoxEnable
  );
  let customHeaderColor = isDarkMode
    ? darkTable?.header?.headColor
    : lightTable?.header?.headColor; //"#575757"
  let customHeaderTextColor = isDarkMode
    ? darkTable?.header?.headTextColor
    : lightTable?.header?.headTextColor;
  let customHeaderTextWeight = lightTable?.header?.textWeight;
  let customHeaderTextSize = lightTable?.header?.textSize;
  let rowColor = isDarkMode
    ? darkTable?.row?.backgroundColor
    : lightTable?.row?.backgroundColor;
  let rowTextSize = lightTable?.row?.textSize;
  let expanadableRowTextSize = lightTable?.expandableRow?.textSize;
  let expanadableRowTextColor = lightTable?.expandableRow?.textColor;
  let expanadableRowHeadingTextSize = lightTable?.expandableRow?.headingSize;
  let expanadableRowHeadingTextWeight = lightTable?.expandableRow?.headingWeight;
  let rowTextWeight = lightTable?.row?.textWeight;
  let expanadableRowTextWeight = lightTable?.expandableRow?.textWeight;
  let specialRow = lightTable?.specialRow;

  let rowTextColor = isDarkMode ? darkTable?.row?.color : lightTable?.row?.color;
  let expandableRowColor = isDarkMode
    ? darkTable?.expandableRow?.backgroundColor
    : lightTable?.expandableRow?.backgroundColor;
  let expandableRowTextColor = isDarkMode
    ? darkTable?.expandableRow?.color
    : lightTable?.expandableRow?.color;
  let expandableRowHeadingColor = isDarkMode
    ? darkTable?.expandableRow?.heading
    : lightTable?.expandableRow?.heading;
  // let customHeaderColor = isDarkMode
  //   ? headerBgColor
  //   : "linear-gradient(to bottom,rgb(8, 28, 29) ,rgb(72, 118, 119))"; //#62962D
  // State for column visibility management
  const [hiddenColumns, setHiddenColumns] = useState([
    // "users_email",
    // "users_firstName",
    // "users_lastName",
    // "users_phoneNo",
    // "users_cnic",
    // "users_fatherName",
    // "users_imageAttachmentId",
    // "users_address",
    // "users_bloodGroup",
  ]);
  const [loading, setLoading] = useState(true);
  const [anchorEl, setAnchorEl] = useState(null);
  const [allColumns, setAllColumns] = useState([]);
  const [hoveredRowId, setHoveredRowId] = useState(null);
  const [expandedRowId, setExpandedRowId] = useState(null);
  const dataGridRef = useRef();
  const [isTableOverflowing, setIsTableOverflowing] = useState(false);
  const [detailPanelPos, setDetailPanelPos] = useState(null);

  // Helper to determine visible and overflowed columns based on available width
  const [visibleColumns, setVisibleColumns] = useState([]);
  const [overflowedColumns, setOverflowedColumns] = useState(
    enableCollapsibleRow ? [] : []
  );
  const [scrollerWidth, setScrollerWidth] = useState(0);
  // Add state to track column order
  const [columnOrder, setColumnOrder] = useState([]);
  // status column update state
  const [editingCell, setEditingCell] = useState({ rowId: null, field: null });
  //column sorting
  const [sortField, setSortField] = useState(null);
  const [sortOrder, setSortOrder] = useState(null); // "asc" | "desc" | null
  const shouldUseCustomHeaders = enableCollapsibleRow;
  const isLocal = configProp?.features?.pagination?.operationalMode === "local";
  //
  const dataGridStyles = {
    border: "none",
    "--unstable_DataGrid-radius": "0px",
    "& .MuiDataGrid-root": {
      color: theme.palette.text.primary,
      backgroundColor: isDarkMode ? theme.palette.background.paper : "#FFFFFF",
      border: "none !important",
      overflowX: "auto",
      // padding: "10px",
    },
    "& .MuiDataGrid-cell": {
      whiteSpace: "normal !important",
      wordBreak: "break-word",
      backgroundColor: rowColor,
      color: rowTextColor,
      fontSize: rowTextSize,
      fontWeight: rowTextWeight,
      padding: enableCollapsibleRow ? 0 : "0px 10px",
      lineHeight: "2.2",
      minHeight: "48px",
      display: "block",
      overflowWrap: "break-word",
      borderBottom: isDarkMode
        ? "1px solid rgba(255, 255, 255, 0.1)"
        : "1px solid rgba(112, 45, 122,0.4)",
      alignContent: "center",
    },
    "& .MuiDataGrid-cell:focus-within": {
      outline: "none",
    },
    "& .MuiDataGrid-row:hover": {
      backgroundColor: isDarkMode
        ? "rgba(255, 255, 255, 0.04)"
        : "rgba(0, 0, 0, 0.04)",
    },

    "& .MuiDataGrid-columnHeaders, & .MuiDataGrid-columnHeaderRow": {
      // backgroundColor: `${customHeaderColor} !important`, // ✅ FORCE override
      // color: `${customHeaderTextColor} !important`,
      // wordBreak: "break-word",
    },
    "& .MuiDataGrid-container--top [role='row']": {
      backgroundColor: `${customHeaderColor} !important`, // ✅ override container var
      color: `${customHeaderTextColor} !important`,
      lineHeight: "normal",

      // fontWeight: customHeaderTextWeight,
      // fontSize: customHeaderTextSize,
    },
    "& .MuiDataGrid-columnHeaders": {
      // backgroundColor: customHeaderColor + " !important", // 🔧 force override
      // color: customHeaderTextColor + " !important",
      lineHeight: "normal",

      // width: "100%",
      borderBottom: isDarkMode
        ? "2px solid rgba(255,255,255,0.1)"
        : "2px solid rgba(112, 45, 122, 0.6)",
      // fontWeight: customHeaderTextWeight,
      // fontSize: customHeaderTextSize,
      ...(shouldUseCustomHeaders ? { display: "none !important" } : {}), // ✅ Here is the fix
    },
    "& .MuiDataGrid-columnHeader": {
      ...(shouldUseCustomHeaders ? { display: "none !important" } : {}), // ✅ Consistent hiding
    },
    "& .MuiDataGrid-columnHeader[role='presentation']": {
      ...(shouldUseCustomHeaders ? { display: "none !important" } : {}),
    },
    "& .MuiDataGrid-columnHeaderTitle": {
      ...(shouldUseCustomHeaders ? { display: "none !important" } : {}),
      fontWeight: customHeaderTextWeight,
      fontSize: customHeaderTextSize,
    },
    "& .MuiDataGrid-virtualScroller": {
      "&::-webkit-scrollbar": {
        width: "10px",
        height: "10px",
      },
      "&::-webkit-scrollbar-thumb": {
        backgroundColor: headerBgColor,
        borderRadius: "10px",
      },
      "&::-webkit-scrollbar-track": {
        backgroundColor: isDarkMode
          ? "rgba(255, 255, 255, 0.05)"
          : "rgba(0, 0, 0, 0.05)",
      },
    },
    "& .MuiDataGrid-footerContainer": {
      display: "none",
    },
    "& .MuiCheckbox-root": {
      color: isDarkMode ? "#a5a4c4" : "#5C5B98",
    },
    "& .MuiDataGrid-columnSeparator": {
      display: "none",
    },
    "--DataGrid-rowBorderColor": "transparent",
  };
  // Add: Function to update detail panel position
  // console.warn("data", additionalProp?.data);
  const updateDetailPanelPosition = useCallback(() => {
    if (!expandedRowId) return;
    const grid = dataGridRef.current;
    if (!grid) return;
    // Find the row node by data-id
    const rowNode = grid.querySelector(
      `.MuiDataGrid-row[data-id="${expandedRowId}"]`
    );
    if (rowNode) {
      const rect = rowNode.getBoundingClientRect();
      // Calculate the height for the detail panel row
      const row = additionalProp?.data?.find((r) => r.id === expandedRowId);
      const isXs = typeof window !== "undefined" && window.innerWidth < 600;

      const detailPanelHeight = computeDetailPanelHeight({
        row,
        overflowedColumns,
        isXs,
      });

      // Apply the same percentage-based height calculation as in getRowHeight
      const heightPercentage = 0.8; // 80% of calculated height
      setDetailPanelPos({
        top: rect.bottom + window.scrollY,
        left: rect.left + window.scrollX,
        width: rect.width,
        // height: Math.floor(detailPanelHeight * heightPercentage),
        height: detailPanelHeight,
      });
    }
  }, [expandedRowId, overflowedColumns]);

  // Simulate async data check
  // useEffect(() => {
  //   setLoading(true);

  //   const timeout = setTimeout(() => {

  //     setLoading(!hasData);
  //   }, 300); // can use 100–200ms debounce to reduce flicker

  //   return () => clearTimeout(timeout);
  // }, [additionalProp?.data, dataProp?.features?.parameters?.fields]);

  useEffect(() => {
    setLoading(true);
    // const isLocal = dataProp?.features?.pagination?.operationalMode === "local";
    const timeout = setTimeout(() => {
      const hasData = isLocal
        ? Array.isArray(additionalProp?.data) && additionalProp?.data.length > 0
        : Array.isArray(dataProp?.features?.parameters?.fields) &&
          dataProp?.features?.parameters?.fields.length > 0;

      setLoading(!hasData);
    }, 300);

    return () => clearTimeout(timeout);
  }, [additionalProp?.data, dataProp]);
  // console.warn("hasData", additionalProp?.data);
  useEffect(() => {
    // Do not hide 'id' by default
    if (hiddenColumns.length === 0) {
      setHiddenColumns([]);
    }
  }, [additionalProp?.data]);

  const sortedRows = React.useMemo(() => {
    if (!sortField || !sortOrder) return additionalProp.data || [];
    return [...(additionalProp.data || [])].sort((a, b) => {
      if (a[sortField] < b[sortField]) return sortOrder === "asc" ? -1 : 1;
      if (a[sortField] > b[sortField]) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [additionalProp.data, sortField, sortOrder]);

  // Add drag handle cursor style
  React.useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `
      [data-rfd-drag-handle-context-id] {
        cursor: pointer !important;
      }
      [data-rfd-drag-handle-context-id]:active {
        cursor: grabbing !important;
      }
    `;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  // Handle visibility icon click
  const handleVisibilityClick = (columnField) => {
    // Prevent hiding 'id' column
    if (columnField === "id") return;
    setHiddenColumns((prev) => [...prev, columnField]);
  };

  // Handle column restoration
  const handleRestoreColumn = (columnField) => {
    setHiddenColumns((prev) => prev.filter((col) => col !== columnField));
  };

  // Handle dropdown menu (only for internal control)
  const handleMenuClick = (event) => {
    if (!isMenuExternallyControlled) {
      setAnchorEl(event.currentTarget);
    }
  };

  const handleMenuClose = () => {
    if (!isMenuExternallyControlled) {
      setAnchorEl(null);
    }
  };

  // Define filteredActions before using it in shouldShowActionsColumn
  const filteredActions = configProp?.features?.rowActions?.permission
    ? dataProp?.features?.rowActions?.actions?.filter((action) =>
        HasPermission(action.permission, currentUserPermissions)
      )
    : dataProp?.features?.rowActions?.actions;

  // Check if actions column should be shown
  const shouldShowActionsColumn = useCallback(() => {
    const hasVisibleDataColumns = allColumns.some(
      (col) => !hiddenColumns.includes(col.field)
    );
    const actionsEnabled =
      configProp?.features?.rowActions?.enable && filteredActions?.length > 0;
    const notViewMode = showSearchIcon?.toLowerCase() !== "view";
    return hasVisibleDataColumns && actionsEnabled && notViewMode;
  }, [allColumns, hiddenColumns, configProp, filteredActions, showSearchIcon]);
  // Helper function to safely display any value in a cell
  function getDisplayValue(value) {
    if (value === undefined || value === null) return "-";
    if (typeof value === "object") {
      if (Array.isArray(value)) return value.join(", ");
      return value.label || value.name || JSON.stringify(value);
    }
    // if(typeof value==="dateTime")
    return value;
  }
  //handle column sorting
  const handleColumnSort = (field) => {
    // console.warn("sort Field", field);
    if (sortField !== field) {
      setSortField(field);
      setSortOrder("asc");
    } else if (sortOrder === "asc") {
      setSortOrder("desc");
    } else if (sortOrder === "desc") {
      setSortField(null);
      setSortOrder(null);
    } else {
      setSortOrder("asc");
    }
  };

  // Use external or internal menu control
  const menuAnchorEl = isMenuExternallyControlled
    ? externalMenuAnchorEl
    : anchorEl;
  const menuHandleOpen = isMenuExternallyControlled
    ? onExternalMenuOpen
    : handleMenuClick;
  const menuHandleClose = isMenuExternallyControlled
    ? onExternalMenuClose
    : handleMenuClose;

  // Expose column visibility state and handlers to parent
  useEffect(() => {
    if (typeof additionalProp?.onColumnVisibilityChange === "function") {
      additionalProp.onColumnVisibilityChange({
        hiddenColumns,
        allColumns,
        handleVisibilityClick,
        handleRestoreColumn,
        shouldShowActionsColumn: shouldShowActionsColumn(),
      });
    }
  }, [
    hiddenColumns,
    allColumns,
    additionalProp,
    handleVisibilityClick,
    handleRestoreColumn,
    shouldShowActionsColumn,
  ]);

  useEffect(() => {
    setCheckboxEnabled(configProp?.grid?.checkBoxEnable);
  }, [configProp?.grid?.checkBoxEnable]);
  // Move this to the top, before any early returns
  const calculateColumnWidths = useCallback(() => {
    if (!dataProp?.features?.parameters?.fields || !additionalProp?.data)
      return [];
    const fields = allColumns;
    // .filter(
    //   (col) => !hiddenColumns.includes(col.field)
    // );

    const rows = additionalProp.data;
    let columns = fields.map((col) => {
      // Get all values for this column
      const values = rows.map((row) => {
        const val = row[col.dynamicKey || col.name];
        if (val == null) return "";
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        if (typeof val === "object" && val.label) return val.label;
        return String(val);
      });
      // Include header name
      const header = col.displayName || col.label || "-000";
      const allStrings = [header, ...values];
      // Find the longest string
      const maxLen = allStrings.reduce(
        (max, str) => Math.max(max, str.length),
        0
      );
      // Heuristic: 8px per char + 32px padding
      let width = maxLen * 8 + 32;
      if (allStrings.length === 1) width = 50; // no data, only header
      width = Math.max(50, Math.min(width, 160));
      return {
        ...col,
        field: col.dynamicKey || col.name,
        headerName: header,
        width,
      };
    });
    // Sort columns according to columnOrder
    if (columnOrder.length > 0) {
      columns = columnOrder
        .map((field) => columns.find((col) => col.field === field))
        .filter(Boolean);
    }
    return columns;
  }, [
    dataProp?.features?.parameters?.fields,
    additionalProp?.data,
    columnOrder,
  ]);
  // Initialize all columns when dataProp changes
  useEffect(() => {
    if (dataProp?.features?.parameters?.fields) {
      // const flatFields = flattenFields();
      const columns = dataProp.features.parameters.fields
        .filter((col) => col?.visible == true || false)
        .map((col, index) => {
          const base = {
            ...col,
            originalIndex: index,
            field: col.dynamicKey || col.name,
            headerName: col.displayName || col.label || "-000",
            width: col.width || 160,
          };
          if (col.type === "date" || col.type === "dateTime") {
            return {
              ...base,
              valueGetter: (params) => {
                if (!params || params.value == null) return undefined;
                if (params.value instanceof Date) return params.value;
                const date = new Date(params.value);
                return isNaN(date.getTime()) ? undefined : date;
              },
            };
          }
          return base;
        });
      setAllColumns(columns);
      setColumnOrder(columns.map((col) => col.field));
    }
  }, [dataProp?.features?.parameters?.fields, additionalProp?.data]);

  const handleCheckboxChange = (selectionModel) => {
    const selectedItems = additionalProp?.data.filter((item) =>
      selectionModel.includes(item.id)
    );
    setbulkActionArray?.(selectedItems);
  };

  const hasDuplicateColumns = () => {
    const columns = dataProp?.features?.parameters?.fields;
    if (!Array.isArray(columns)) return false;
    const columnNames = columns
      .map((col) => col?.dynamicKey || col?.name)
      .filter((name) => name != null);
    const uniqueColumnNames = new Set(columnNames);
    return columnNames.length !== uniqueColumnNames.size;
  };

  const handleAction = (action, row, index) => {
    if (onRowAction) {
      // Don't call onRowAction for 'start' action since socket emission is the primary action
      if (action.name !== "start") {
        onRowAction(action, row, index);
      }
    } else {
      onUpdateRefreshData(action, row, index);
    }
  };

  // Expose column visibility functionality to parent component
  const getColumnVisibilityState = useCallback(
    () => ({
      hiddenColumns,
      allColumns,
      handleVisibilityClick,
      handleRestoreColumn,
      shouldShowActionsColumn: shouldShowActionsColumn(),
      menuAnchorEl,
      handleMenuOpen: menuHandleOpen,
      handleMenuClose: menuHandleClose,
    }),
    [
      hiddenColumns,
      allColumns,
      handleVisibilityClick,
      handleRestoreColumn,
      shouldShowActionsColumn,
      menuAnchorEl,
      menuHandleOpen,
      menuHandleClose,
    ]
  );

  // Expose the function through additionalProp
  useEffect(() => {
    if (additionalProp?.setColumnVisibilityState) {
      additionalProp.setColumnVisibilityState(getColumnVisibilityState);
    }
  }, [
    additionalProp?.setColumnVisibilityState,
    getColumnVisibilityState,
    additionalProp,
  ]);

  // Add expand column at the end

  const expandColumn = {
    field: "expand",
    headerName: "",
    width: 50,
    sortable: false,
    renderCell: (params) => {
      if (!enableCollapsibleRow) return null;
      const isExpanded = expandedRowId === params.id;
      if (overflowedColumns.length === 0) return null;
      if (params.row.isDetailPanel) return null;
      return (
        <IconButton
          size="small"
          style={
            {
              // marginTop: "8px",
            }
          }
          onClick={(e) => {
            let rowNode = e.currentTarget.closest(".MuiDataGrid-row");
            if (rowNode) {
              if (isExpanded) {
                setExpandedRowId(null);
                setDetailPanelPos(null);
              } else {
                const rect = rowNode.getBoundingClientRect();
                setDetailPanelPos({
                  top: rect.bottom + window.scrollY,
                  left: rect.left + window.scrollX,
                  width: rect.width,
                });
                setExpandedRowId(params.id);

                // Use the new function to update position
                setTimeout(() => {
                  updateDetailPanelPosition();
                }, 0);
              }
            }
          }}
        >
          <Tooltip title={isExpanded ? "Collapse" : "Expand"}>
            <ArrowRightRoundedIcon
              fontSize="medium"
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                transform: isExpanded ? "rotate(90deg)" : "rotate(0deg)",
                transition: "transform 0.2s",
              }}
            />
          </Tooltip>
        </IconButton>
      );
    },
  };

  const actionColumn = {
    field: "actions",
    headerName: "Actions",
    width: 160,
    sortable: false,
    renderCell: (params) => {
      // Hide actions for detail panel row
      if (params.row.isDetailPanel) return null;

      // Use dynamic configuration if provided, otherwise fall back to legacy logic
      const getRowSpecificActions = (row) => {
        // If rowActionsConfig is provided, use it for dynamic filtering
        if (rowActionsConfig && Array.isArray(rowActionsConfig.conditions)) {
          const baseActions = filteredActions || [];

          // Check each condition in the configuration
          for (const condition of rowActionsConfig.conditions) {
            const fieldValue = row[condition.field];
            const matchesCondition = condition.operator === 'equals'
              ? fieldValue === condition.value
              : condition.operator === 'not_equals'
              ? fieldValue !== condition.value
              : condition.operator === 'contains'
              ? String(fieldValue).includes(condition.value)
              : condition.operator === 'in'
              ? condition.value.includes(fieldValue)
              : false;

            if (matchesCondition) {
              // Return filtered actions based on the condition
              if (condition.actionsToShow && condition.actionsToShow.length > 0) {
                return baseActions.filter(action =>
                  condition.actionsToShow.includes(action.name)
                );
              } else if (condition.actionsToHide && condition.actionsToHide.length > 0) {
                return baseActions.filter(action =>
                  !condition.actionsToHide.includes(action.name)
                );
              }
            }
          }

          // If no conditions match, return all actions or default actions
          return rowActionsConfig.defaultActions || baseActions;
        }

        // Fallback to legacy logic for backward compatibility
        const rowStatus = row.status || row.enrollements_status || row.subcomponents_status || 'active';
        const baseActions = filteredActions || [];

        switch (rowStatus.toLowerCase()) {
          case 'inactive':
            return baseActions.filter(action =>
              !['Edit', 'Delete'].includes(action.name)
            );
          case 'active':
            return baseActions;
          case 'pending':
            return baseActions.filter(action =>
              action.name === 'View'
            );
          default:
            return baseActions;
        }
      };

      const getDisabledActions = (row) => {
        // If rowActionsConfig is provided, use it for dynamic disabling
        console.log("matchesCondition", row,rowActionsConfig) 
        if (rowActionsConfig && Array.isArray(rowActionsConfig.conditions)) {
          for (const condition of rowActionsConfig.conditions) {
            const fieldValue = row[condition.field];
            const matchesCondition = condition.operator === 'equals'
              ? fieldValue === condition.value
              : condition.operator === 'not_equals'
              ? fieldValue !== condition.value
              : condition.operator === 'contains'
              ? String(fieldValue).includes(condition.value)
              : condition.operator === 'in'
              ? condition.value.includes(fieldValue)
              : false;
             console.log("matchesCondition", row,rowActionsConfig) 
            if (matchesCondition) {
              // If actionsToDisable is explicitly set, use it
              if (condition.actionsToDisable && condition.actionsToDisable.length > 0) {
                return condition.actionsToDisable;
              }

              // If actionsToShow is set, disable all actions that are NOT in the show list
              if (condition.actionsToShow && condition.actionsToShow.length > 0) {
                const baseActions = filteredActions || [];
                return baseActions
                  .map(action => action.name)
                  .filter(actionName => !condition.actionsToShow.includes(actionName));
              }

              // If actionsToHide is set, disable those actions
              if (condition.actionsToHide && condition.actionsToHide.length > 0) {
                return condition.actionsToHide;
              }
            }
          }
          return rowActionsConfig.disabledActionsByDefault || [];
        }

        // Fallback to legacy logic
        const rowStatus = row.status || row.enrollements_status || row.subcomponents_status || 'active';
        switch (rowStatus.toLowerCase()) {
          case 'inactive':
            return ['Edit', 'Delete'];
          case 'pending':
            return ['Edit', 'Delete', 'start'];
          default:
            return [];
        }
      };

      const rowSpecificActions = getRowSpecificActions(params.row);
      const disabledActions = getDisabledActions(params.row);

      return enableRowActions ? (
        <Box sx={{ display: "flex", mt: 0.8 }}>
          <ActionButtons
            displayMode="table"
            color={actionButtonColor}
            actions={rowSpecificActions}
            isDarkMode={isDarkMode}
            onAction={(action, index) =>
              handleAction(action, params.row, index)
            }
            rowData={params.row}
            disabledActions={disabledActions}
          />
        </Box>
      ) : null;
    },
  };

  const handleRowDoubleClick = () => {
    if (configProp?.grid?.checkBoxEnable) {
      setCheckboxEnabled((prev) => !prev);
    }
  };

  useEffect(() => {
    const checkOverflow = () => {
      const grid = dataGridRef.current;
      let scroller = null;
      if (grid) {
        // Try multiple possible scrollable containers
        scroller =
          grid.querySelector(".MuiDataGrid-virtualScroller") ||
          grid.querySelector(".MuiDataGrid-main") ||
          grid.querySelector(".MuiDataGrid-window");
        if (scroller) {
          setScrollerWidth(scroller.scrollWidth);
          setIsTableOverflowing(scroller.scrollWidth > scroller.clientWidth);
        } else {
          setIsTableOverflowing(false);
        }
      }
    };
    checkOverflow();
    window.addEventListener("resize", checkOverflow);
    return () => window.removeEventListener("resize", checkOverflow);
  }, [dataProp, allColumns]);

  const expandColWidth = expandColumn.width;
  // console.warn("expand col", expandColWidth);
  const actionColWidth = actionColumn.width;
  const actionsEnabled = shouldShowActionsColumn();


  const recalculateColumns = useCallback(
    (allCalculatedColumns) => {
      const grid = dataGridRef.current;
      if (!grid) return { visCols: [], overCols: [] };
      if (!enableCollapsibleRow)
        return { visCols: allCalculatedColumns, overCols: [] };

      const containerWidth = grid.offsetWidth || 1200;
      let widthUsed = expandColumn.width;

      if (enableRowActions && shouldShowActionsColumn())
        widthUsed += actionColumn.width || 100;

      const visCols = [];
      const overCols = [];

      for (let col of allCalculatedColumns) {
        if (hiddenColumns.includes(col.field)) continue; // skip hidden

        const colWidth = col.width || 120;
        const fudge = 20;

        if (widthUsed + colWidth <= containerWidth - fudge) {
          visCols.push(col);
          widthUsed += colWidth;
        } else {
          overCols.push(col);
        }
      }

      return { visCols, overCols };
    },
    [shouldShowActionsColumn, hiddenColumns]
  );

  // Update detail panel position on window resize or table scroll, and when columns change
  useEffect(() => {
    if (!expandedRowId) return;
    const handleResizeOrScroll = () => updateDetailPanelPosition();
    window.addEventListener("resize", handleResizeOrScroll);
    window.addEventListener("tableLayoutChanged", handleResizeOrScroll);
    const grid = dataGridRef.current;
    if (grid) grid.addEventListener("scroll", handleResizeOrScroll);
    // Also update when columns change
    updateDetailPanelPosition();
    return () => {
      window.removeEventListener("resize", handleResizeOrScroll);
      window.removeEventListener("tableLayoutChanged", handleResizeOrScroll);
      if (grid) grid.removeEventListener("scroll", handleResizeOrScroll);
    };
  }, [
    expandedRowId,
    updateDetailPanelPosition,
    visibleColumns,
    overflowedColumns,
    allColumns,
  ]);

  
  useEffect(() => {
    // const recalcSource = calculateColumnWidths(); // already filtered
    // const { visCols, overCols } = recalculateColumns(recalcSource);
    const allCalculated = calculateColumnWidths(); // all columns, not pre-filtered
    const { visCols, overCols } = recalculateColumns(allCalculated);
    setVisibleColumns(visCols);
    setOverflowedColumns(overCols);
    if (expandedRowId) {
      updateDetailPanelPosition();
    }
  }, [
    allColumns,
    expandColWidth,
    actionColWidth,
    actionsEnabled,
    hiddenColumns.length,
    recalculateColumns,
    expandedRowId,
    updateDetailPanelPosition,
    additionalProp?.data,
  ]);

  // Initialize columnOrder when allColumns change
  useEffect(() => {
    if (
      allColumns.length > 0 &&
      additionalProp?.data?.length > 0 &&
      columnOrder.length === 0
    ) {
      setColumnOrder(allColumns.map((col) => col.field));
    }
  }, [allColumns, columnOrder.length, additionalProp?.data]);

  // Helper to build rows with detail panel inserted (for custom cell spanning all columns)
  const buildRowsWithDetailPanel = (data = []) => {
    if (!data) return [];
    const rows = [];
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      rows.push(row);
      if (row.id === expandedRowId && overflowedColumns.length > 0) {
        rows.push({
          id: `detail-panel-${row.id}`,
          overflowedColumns: overflowedColumns,
          isDetailPanel: true,
          originalRow: row,
        });
      }
    }
    return rows;
  };
  //
  const overFlowedColumnsPerRow = () => {
    let length = overflowedColumns?.length;

    if (length % 5 === 0) {
      return 5;
    } else if (length % 5 === 1) {
      return 3;
    } else if (length % 5 <= 3) {
      return 4;
    } else if (length % 5 > 3) {
      return 5;
    }
  };
  // Helper to calculate max content length in a row for given columns
  const getMaxContentLengthForRow = (row, columns) => {
    // console.warn("getMaxContentLengthForRow", row, "jsjwqkdjswqd", columns);
    let maxHeight = 0;
    columns.forEach((col) => {
      const fieldKey = col.dynamicKey || col.field || col.name;
      const value = row[fieldKey];
      const displayValue = getDisplayValue(value);
      const contentLength = String(displayValue + row[fieldKey]).length;
      const threshold = col.contentThreshold || 15;
      const extraHeightPerChar = col.extraHeightPerChar || 0.45;
      const extra =
        contentLength > threshold
          ? (contentLength - threshold) * extraHeightPerChar
          : 0;

      maxHeight = Math.max(maxHeight, extra);
    });
    return maxHeight;
  };
  const computeDetailPanelHeight = ({ row, overflowedColumns, isXs }) => {
    if (!row || !overflowedColumns) return 80;

    const columnsPerRow = isXs ? 2 : overFlowedColumnsPerRow();
    const numRows = Math.ceil(overflowedColumns.length / columnsPerRow);
    const baseRowHeight = isXs ? 70 : 70;
    const extraHeight = getMaxContentLengthForRow(row, overflowedColumns);
    const rowHeight = baseRowHeight + extraHeight;

    return Math.max(80, numRows * rowHeight) + 10; // +10 padding for visual safety
  };

  const getRowHeight = (params) => {
    if (params.model && params.model.isDetailPanel) {
      const overflowedColumns = params.model.overflowedColumns || [];
      const row = params.model.originalRow || params.model.row || {};
      const isXs = typeof window !== "undefined" && window.innerWidth < 600;

      return computeDetailPanelHeight({ row, overflowedColumns, isXs });
    }
    return null;
  };


  function GETDisplayValue(value, fieldKey) {
    if (value === undefined || value === null || value === "") return "-";
    // Date handling: if the fieldKey or value suggests a date, format it
    if (
      (typeof fieldKey === "string" &&
        fieldKey.toLowerCase().includes("date")) ||
      (typeof value === "string" &&
        (value.match(/^\d{4}-\d{2}-\d{2}/) ||
          value.match(/^\d{2}\/\d{2}\/\d{4}/)))
    ) {
      let rawValue = value;
      if (typeof rawValue === "string" && rawValue.includes(" ")) {
        rawValue = rawValue.replace(" ", "T");
      }
      const dateObj = new Date(rawValue);
      if (!isNaN(dateObj.getTime())) {
        return dateObj.toLocaleDateString("en-GB", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        });
      } else {
        return "-";
      }
    }
    if (typeof value === "object") {
      if (Array.isArray(value)) return value.join(", ");
      return value.label || value.name || JSON.stringify(value);
    }
    return value;
  }
  const customColumns = [
    expandColumn,
    ...visibleColumns
      .filter(
        (col) =>
          col &&
          !overflowedColumns
            ?.filter(
              (item) => item && typeof item === "object" && "field" in item
            )
            ?.some((overflowed) => overflowed.field === col.field)
      )

      // .filter(
      //   (col) =>
      //     !overflowedColumns.some(
      //       (overflowed) => overflowed?.field === col.field
      //     )
      // )
      .map((col) => {
        if (col.field === "users_dateOfBirth") {
          return {
            ...col,
            renderCell: (params) => {
              if (!params || !params.row) {
                return (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "flex-start",
                      alignItems: "center",
                      width: "100%",
                      height: "100%",
                    }}
                  >
                    {"-"}
                  </Box>
                );
              }
              let rawValue =
                params.value ?? params.row[col.dynamicKey || col.name];
              if (!rawValue || rawValue === "") {
                return (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "flex-start",
                      alignItems: "center",
                      width: "100%",
                      height: "100%",
                    }}
                  >
                    {"-"}
                  </Box>
                );
              }
              if (typeof rawValue === "string" && rawValue.includes(" ")) {
                rawValue = rawValue.replace(" ", "T");
              }
              const dateObj = new Date(rawValue);
              return (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flex-start",
                    alignItems: "center",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  {!isNaN(dateObj.getTime()) ? (
                    <Typography sx={{ fontSize: 15 }} component="span">
                      {dateObj.toLocaleDateString("en-GB", {
                        year: "numeric",
                        month: "2-digit",
                        day: "2-digit",
                      })}
                    </Typography>
                  ) : (
                    "-"
                  )}
                </Box>
              );
            },
            valueGetter: (params) => {
              if (!params || !params.row) return null;
              return params.row[col.dynamicKey || col.name] ?? null;
            },
          };
        }
        if (col.type === "image") {
          return {
            ...col,
            renderCell: (params) => {
              if (params.row.isDetailPanel) return null;

              if (Array.isArray(params.value)) {
                return (
                  <AvatarGroup max={3}>
                    {params.value.map((imageUrl, index) => (
                      <Avatar
                        key={index}
                        alt={`Image ${index + 1}`}
                        src={imageUrl}
                        style={{ border: `2px solid ${borderColor}` }}
                      />
                    ))}
                  </AvatarGroup>
                );
              }
              if (
                typeof params.value === "string" &&
                params.value.startsWith("http")
              ) {
                return (
                  <Avatar
                    alt="Single Image"
                    src={params.value}
                    // style={{ border: `2px solid ${borderColor}` }}
                  />
                );
              }
              return <span>-</span>;
            },
          };
        }
        return {
          ...col,
          renderCell: (params) => {
            if (params.row.isDetailPanel) return null;
            // Special style for email column
            if (col.field === "users_email") {
              return (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flexStart",
                    alignItems: "center",
                    width: "100%",
                    minWidth: 0,
                    maxWidth: "100%",
                    height: "100%",
                    color: specialRow?.color,
                    fontWeight: specialRow?.textWeight,
                  }}
                >
                  {params.value ? (
                    <>
                      <a
                        href={`mailto:${params.value}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          color: "#4A90E2",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontWeight: 500,
                          paddingRight: "10px",
                        }}
                      >
                        {params.value}
                      </a>
                      {/* <IconButton onClick={() => handleCopyEmail(params.value)}>
                        <FileCopyOutlinedIcon
                          sx={{
                            width: "0.8rem",
                            height: "0.8rem",
                            color: "#4A90E2",
                          }}
                        />
                      </IconButton> */}
                    </>
                  ) : (
                    "-"
                  )}
                </Box>
              );
            }
            if (col.field === "users_status") {
              if (params.row.isDetailPanel) return null;

              const isEditing =
                editingCell.rowId === params.id &&
                editingCell.field === "users_status" &&
                userStatusUpdationPermission &&
                enableUserStatusUpdation;

              const statusOptions = col.options || [];
              const statusColors = isDarkMode
                ? {
                    active: appearanceProp?.dark?.grid?.statusActive,
                    inactive: appearanceProp?.dark?.grid?.statusInactive,
                  }
                : {
                    active: appearanceProp?.light?.grid?.statusActive,
                    inactive: appearanceProp?.light?.grid?.statusInactive,
                  };
              if (isEditing) {
                return (
                  <EditableStatusCell
                    value={params.value}
                    statusOptions={statusOptions}
                    statusColors={statusColors}
                    onChange={(e) =>
                      handleStatusChange(params.id, e.target.value)
                    }
                    onBlur={() => setEditingCell({ rowId: null, field: null })}
                  />
                );
              }

              return (
                <div
                  onClick={() =>
                    setEditingCell({
                      rowId: params.id,
                      field: "users_status",
                    })
                  }
                  style={{
                    background: statusColors[params.value]?.background,
                    color: statusColors[params.value]?.color,
                    borderRadius: "1rem",
                    fontWeight: 300,
                    cursor:
                      userStatusUpdationPermission &&
                      enableUserStatusUpdation &&
                      "pointer",
                    padding: "4px 8px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    textAlign: "center",
                    height: "50%",
                    width: "70%",
                    minWidth: "70px",
                  }}
                >
                  {getDisplayValue(params.value)}
                </div>
              );
            }

            if (
              params.value &&
              typeof params.value === "object" &&
              !Array.isArray(params.value)
            ) {
              return (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flexStart",
                    alignItems: "center",
                    width: "100%",
                    height: "100%",
                    lineHeight: "normal",
                  }}
                >
                  {getDisplayValue(params.value)}
                </Box>
              );
            } else {
              return (
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flexStart",
                    alignItems: "center",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  {getDisplayValue(params.value) || "-"}
                </Box>
              );
            }
          },
        };
      }),
    shouldShowActionsColumn() ? actionColumn : null,
  ].filter(Boolean);

  // Custom cell renderer for detail panel row
  const renderCell = (params) => {
    if (params.row.isDetailPanel && params.field === customColumns[0].field) {
      // Only render in the first column, span all columns
      return {
        props: {
          colSpan: customColumns.length,
        },
        children: (
          <Box
            sx={{
              background: isDarkMode ? headerBgColor : "red", //#DCDCDC
              boxShadow: isDarkMode && "10px 20px 20px rgba(0, 0, 0, 0.3)",
              mt: 0,
              mr: { xs: "40%", sm: "0" },
              display: "flex",
              flexWrap: "wrap",
              gap: "0.1rem",
              justifyContent: "center",
              alignItems: "center",
              minHeight: "60px",
              borderTop: !isDarkMode && "1px solid rgba(32, 16, 16, 0.12)",
              border: "1px solid rgba(0,0,0,0.08)",
              borderRadius: "8px",
              transition: "all 0.2s ease",
              // height: "auto",
              height: "100%",
              width: "100%",
            }}
          >
            {overflowedColumns.map((col, idx) => (
              <Box
                key={col.field}
                sx={{
                  minWidth: col.width,
                  maxWidth: col.width,
                  flex: `1 1 ${col.width}px`,
                  overflowWrap: "break-word",
                  wordBreak: "break-word",
                  whiteSpace: "normal",
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  transition: "all 0.2s ease",
                  width: "100%",
                }}
              >
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: "bold",
                    color: headerTextColor,
                    textAlign: "center",
                  }}
                >
                  {col.headerName}:
                </Typography>
                <Typography
                  variant="body2"
                  sx={{ color: textColor, textAlign: "center", ml: 1 }}
                >
                  {params.row.originalRow[col.field] || "-"}
                </Typography>
              </Box>
            ))}
          </Box>
        ),
      };
    }

    // For other columns in detail panel row, hide cell
    if (params.row.isDetailPanel) {
      return { props: { style: { display: "none" } }, children: null };
    }
    // Default rendering

    return null;
  };

  //calculate width for overflowed column separetly
  function calculateOverflowedColumnWidth(col, rows) {
    // Get all values for this column
    const values = rows.map((row) => {
      const val = row[col.dynamicKey || col.name];
      if (val == null) return "";
      if (typeof val === "string") return val;
      if (typeof val === "number") return val.toString();
      if (typeof val === "object" && val.label) return val.label;
      return String(val);
    });
    // Include header name
    const header = col.displayName || col.label || "-000";
    const allStrings = [header, ...values];
    // Find the longest string
    const maxLen = allStrings.reduce(
      (max, str) => Math.max(max, str.length),
      0
    );
    // Heuristic: 8px per char + 32px padding
    let width = maxLen * 8 + 32;
    width = Math.max(120, Math.min(width, 180)); // min 60, max 180
    return width;
  }

  // Only include columns that are not overflowed and not hidden
  const visibleProcessedColumns = calculateColumnWidths()
    .filter(
      (col) =>
        !overflowedColumns
          ?.filter(
            (item) => item && typeof item === "object" && "field" in item
          )
          ?.some((overflowed) => overflowed.field === col.field)

      // !overflowedColumns
      //   .filter(Boolean)
      //   .some((overflowed) => overflowed?.field === col.field)
    )
    .map((col) => {
      if (col.type === "image") {
        return {
          ...col,
          renderCell: (params) => {
            if (Array.isArray(params.value)) {
              return (
                <AvatarGroup max={3} style={{ width: "100%" }}>
                  {params.value.map((imageUrl, index) => (
                    <Avatar
                      key={index}
                      alt={`Image ${index + 1}`}
                      src={imageUrl}
                      style={{ border: `2px solid ${borderColor}` }}
                    />
                  ))}
                </AvatarGroup>
              );
            }
            if (
              typeof params.value === "string" &&
              params.value.startsWith("http")
            ) {
              return (
                <Avatar
                  alt="Single Image"
                  src={params.value}
                  style={{ border: `2px solid ${borderColor}` }}
                />
              );
            }
            return <span>-</span>;
          },
        };
      }
      return {
        ...col,
        renderCell: (params) => {
          if (
            params.value &&
            typeof params.value === "object" &&
            !Array.isArray(params.value)
          ) {
            return (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  width: "100%",
                  minWidth: 0,
                  maxWidth: "100%",
                  height: "100%",
                }}
              >
                {getDisplayValue(params.value)}
              </Box>
            );
          } else {
            return (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  width: "100%",
                  // minHeight: 80,
                  minWidth: 0,
                  maxWidth: "100%",
                  height: "100%",
                  // backgroundColor: "red",
                }}
              >
                {getDisplayValue(params.value)}
              </Box>
            );
          }
        },
      };
    });

  // //.warn("visible Columns: ", visibleProcessedColumns);
  // Move early returns after all hooks are called
  if (hasDuplicateColumns()) {
    return showWarningToast(
      "Cannot display a table with more than one same parameters"
    );
  }

  // Show skeleton loading while data is being loaded
  if (loading) {
    return <TableSkeleton />;
  }

  if (
    !additionalProp?.data?.length &&
    !dataProp?.features?.parameters?.fields?.length
  ) {
    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <Typography
          variant="h6"
          sx={{ color: textColor || (isDarkMode ? "#c7c6ff" : "#260143") }}
        >
          No data found
        </Typography>
      </div>
    );
  }

  // Update handleColumnDragEnd to update columnOrder
  const handleColumnDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;

    const sourceId = source.droppableId;
    const destId = destination.droppableId;

    const getDraggable = (cols) =>
      cols.filter(
        (col) =>
          !hiddenColumns.includes(col.field) &&
          col.field !== "id" &&
          col.field !== "actions"
      );

    const visibleDraggables = getDraggable(visibleColumns);
    const overflowDraggables = getDraggable(overflowedColumns);

    const sourceCols =
      sourceId === "main-table" ? visibleDraggables : overflowDraggables;
    const destCols =
      destId === "main-table" ? visibleDraggables : overflowDraggables;

    const movedCol = sourceCols[source.index];
    if (!movedCol) return;

    // Reorder columns
    const newVisible = [...visibleDraggables];
    const newOverflow = [...overflowDraggables];

    // Remove from source
    if (sourceId === "main-table") newVisible.splice(source.index, 1);
    else newOverflow.splice(source.index, 1);

    // Insert into destination
    if (destId === "main-table")
      newVisible.splice(destination.index, 0, movedCol);
    else newOverflow.splice(destination.index, 0, movedCol);

    const newActive = [...newVisible, ...newOverflow].map((col) => col.field);

    // Merge into columnOrder keeping hidden columns in place
    const newColumnOrder = columnOrder.map((field) =>
      hiddenColumns.includes(field) ? field : newActive.shift()
    );

    setColumnOrder(newColumnOrder);

    // Sync allColumns
    setAllColumns((prev) =>
      newColumnOrder
        .map((field) => prev.find((col) => col.field === field))
        .filter(Boolean)
    );

    // Recalculate layout
    const { visCols, overCols } = recalculateColumns(
      allColumns.filter((col) => !hiddenColumns.includes(col.field))
    );
    setVisibleColumns(visCols);
    setOverflowedColumns(overCols);

    if (expandedRowId) {
      updateDetailPanelPosition();
    }
  };

  // Helper to get columns in current order (visible, not hidden, not overflowed)
  // const orderedVisibleColumns = columnOrder
  //   .map((field) => visibleProcessedColumns.find((col) => col.field === field))
  //   .filter(Boolean);
  const orderedVisibleColumns = columnOrder
    .filter((field) => !hiddenColumns.includes(field))
    .map((field) => visibleProcessedColumns.find((col) => col.field === field))
    .filter(Boolean);

  //
  const handleStatusChange = (rowId, newValue) => {
    if (typeof additionalProp?.onStatusChange === "function") {
      additionalProp.onStatusChange(rowId, newValue);
    }
    setEditingCell({ rowId: null, field: null });
  };
  // useMemo(() => {

  // console.warn("length:", overFlowedColumnsPerRow);
  // }, [overflowedColumns?.length]);
  // console.warn("overflowed:", overflowedColumns);
  return (
    <div
      ref={dataGridRef}
      style={{
        width: "100%",
        // boxShadow:
        //   "8px 0 4px -8px rgba(0,0,0,0.8), -8px 0 4px -8px rgba(0,0,0,0.2)",
        // borderRadius: "12px",
        // background: isDarkMode ? theme.palette.background.paper : "#fff",
      }}
    >
      {/* Column visibility dropdown - only show if not externally controlled */}
      {!isMenuExternallyControlled && (
        <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 1 }}>
          <Button
            onClick={handleMenuClick}
            startIcon={<WysiwygOutlinedIcon />}
            aria-label="Column Visibility"
            sx={{
              color: headerTextColor,
              backgroundColor: headerBgColor,
              "&:hover": {
                backgroundColor: isDarkMode
                  ? "rgba(255,255,255,0.1)"
                  : "rgba(0,0,0,0.1)",
              },
            }}
          ></Button>
        </Box>
      )}

      {/* Single DragDropContext for both droppables */}
      {useDragAndDropFeature && shouldUseCustomHeaders ? (
        <DragDropContext onDragEnd={handleColumnDragEnd}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              // mt: 1,
              minHeight: "60px",
              fontSize: "1rem",
              borderBottom: isDarkMode
                ? "2px solid rgba(255, 255, 255, 0.1)"
                : "2px solid rgba(112, 45, 122,0.4)",
              // top: 0,
              // position: "sticky",
            }}
          >
            {/* Main table columns droppable */}
            <Droppable droppableId="main-table" direction={"horizontal"}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  style={{
                    display: "flex",
                    border: snapshot.isDraggingOver
                      ? `2px dashed ${isDarkMode ? "#6C63FF" : "#7479ed"}`
                      : "none",
                    borderRadius: snapshot.isDraggingOver ? "8px" : "4px",
                    backgroundColor: customHeaderColor,

                    // paddingInlineStart: "50px",
                    padding: snapshot.isDraggingOver ? "4px" : "0px",
                    transition: "all 0.2s ease",
                    width: "100%",
                  }}
                >
                  {/* Render all visibleColumns in order, only wrap draggable ones in Draggable */}
                  <Box
                    key="expand-header"
                    sx={{
                      width: expandColumn.width,
                      minWidth: expandColumn.width,
                      maxWidth: expandColumn.width,
                      // background: customHeaderColor, //headerBgColor
                      color: customHeaderTextColor,
                      fontWeight: "bold",
                      display: "flex",
                      p: 1,
                      alignItems: "flexStart",
                      justifyContent: "center",
                      borderTopLeftRadius: 0,
                      borderTopRightRadius: 0,
                      height: 10,
                    }}
                  >
                    <IconButton
                      size="medium"
                      style={{
                        opacity: 0,
                        width: "80px",
                        height: "100%",
                        // marginRight: 1,
                        // background: customHeaderColor,
                      }}
                    >
                      <ArrowRightRoundedIcon />
                    </IconButton>
                  </Box>
                  {orderedVisibleColumns.map((col, index) => {
                    const isDraggable =
                      col.field !== "id" && col.field !== "actions";
                    if (isDraggable) {
                      return (
                        <Draggable
                          key={col.field}
                          draggableId={col.field}
                          index={index}
                        >
                          {(provided, snapshot) => (
                            <Box
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              sx={{
                                width: col.width,
                                minWidth: col.width,
                                maxWidth: col.width + "70px",
                                // background: customHeaderColor, //headerBgColor
                                color: customHeaderTextColor,
                                fontWeight: "bold",
                                display: "flex",

                                alignItems: "center",
                                justifyContent: "flexStart",

                                boxShadow: snapshot.isDragging
                                  ? "0 4px 12px rgba(0,0,0,0.2)"
                                  : undefined,
                                borderTopLeftRadius:
                                  index === 0 ? 4 : undefined,
                                borderRadius: snapshot.isDragging
                                  ? "12px"
                                  : undefined,
                                height: "auto",
                                cursor: snapshot.isDragging
                                  ? "grabbing"
                                  : "pointer",
                                transition: "all 0.2s ease",
                                transform: snapshot.isDragging
                                  ? "rotate(5deg) scale(1.05)"
                                  : "none",
                                zIndex: snapshot.isDragging ? 1000 : "auto",
                                opacity: snapshot.isDragging ? 0.8 : 1,
                                // cursor: "pointer",
                                position: "relative",
                                "& .sort-icon": {
                                  opacity: 0,
                                  transition: "opacity 0.2s",
                                },

                                "&:hover .sort-icon": {
                                  opacity: 0.5,
                                },
                                "& .sort-icon.sorted": {
                                  opacity: 1,
                                },
                              }}
                              onClick={() => handleColumnSort(col.field)}
                            >
                              {col.field === "expand" &&
                              overflowedColumns.length > 0 ? (
                                <IconButton
                                  size="medium"
                                  style={{
                                    opacity: 0,
                                    width: "70px",
                                    height: "100%",
                                  }}
                                >
                                  <ArrowRightRoundedIcon />
                                </IconButton>
                              ) : col.field === "expand" ? (
                                ""
                              ) : (
                                col.headerName
                              )}
                              <span
                                className={`sort-icon${
                                  sortField === col.field ? " sorted" : ""
                                }`}
                                style={{
                                  marginLeft: "3px",
                                  marginTop: "2px",
                                  color: isDarkMode ? headerTextColor : "black",
                                  // No opacity here!
                                }}
                              >
                                {sortField === col.field ? (
                                  sortOrder === "asc" ? (
                                    <ArrowUpward fontSize="12px" />
                                  ) : sortOrder === "desc" ? (
                                    <ArrowDownward fontSize="12px" />
                                  ) : (
                                    <ArrowUpward fontSize="12px" />
                                  )
                                ) : (
                                  <SortByAlphaRoundedIcon fontSize="25px" />
                                )}
                              </span>
                            </Box>
                          )}
                        </Draggable>
                      );
                    } else {
                      // Static header cell for non-draggable columns
                      return (
                        <Box
                          key={col.field}
                          sx={{
                            width: col.width,
                            minWidth: col.width,
                            maxWidth: col.width,
                            // background: customHeaderColor, //headerBgColor
                            color: customHeaderTextColor,
                            fontWeight: "bold",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "flexStart",

                            borderTopLeftRadius: 0,
                            borderTopRightRadius: 0,
                            height: "auto",
                            cursor: "pointer",
                            position: "relative",
                            "& .sort-icon": {
                              opacity: 0,
                              transition: "opacity 0.2s",
                            },
                            "&:hover .sort-icon": {
                              opacity: 1,
                            },
                          }}
                          onClick={() => handleColumnSort(col.field)}
                        >
                          {col.headerName}
                          <span
                            className="sort-icon"
                            style={{
                              marginLeft: 4,
                              // No opacity here!
                            }}
                          >
                            {sortField === col.field ? (
                              sortOrder === "asc" ? (
                                <ArrowUpward fontSize="small" />
                              ) : sortOrder === "desc" ? (
                                <ArrowDownward fontSize="small" />
                              ) : (
                                <Sort fontSize="small" />
                              )
                            ) : (
                              <Sort fontSize="small" />
                            )}
                          </span>
                        </Box>
                      );
                    }
                  })}
                  {/* Action column header (not draggable) */}
                  {shouldShowActionsColumn() && enableRowActions && (
                    <Box
                      sx={{
                        width: actionColumn.width,
                        minWidth: actionColumn.width,
                        maxWidth: actionColumn.width,
                        // background: customHeaderColor, //headerBgColor
                        color: customHeaderTextColor,
                        fontWeight: "bold",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "flexStart",

                        borderTopLeftRadius: 0,
                        borderTopRightRadius: 4,
                        height: "auto",
                        ml: 1,
                      }}
                    >
                      {actionColumn.headerName}
                    </Box>
                  )}

                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </Box>

          {/* Detail panel for overflowed columns  */}
          {expandedRowId &&
            detailPanelPos &&
            detailPanelPos.height &&
            overflowedColumns.length > 0 &&
            (() => {
              const row = additionalProp?.data?.find(
                (r) => r.id === expandedRowId
              );
              if (!row) return null;
              return ReactDOM.createPortal(
                <Droppable droppableId="overflow-panel" direction="horizontal">
                  {(provided, snapshot) => (
                    <Box
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      sx={{
                        background: isDarkMode ? headerBgColor : "#DCDCDC",
                        boxShadow:
                          isDarkMode && "10px 20px 20px rgba(0, 0, 0, 0.3)",
                        mt: 0,
                        mb: 0,
                        // p: 0.5,
                        position: "absolute",
                        // zIndex: 1300,
                        left: detailPanelPos.left,
                        top: detailPanelPos.top,
                        width: detailPanelPos.width,
                        height: detailPanelPos.height,
                        // height: getrowhieght,
                        maxWidth: "100vw",

                        display: "grid",
                        gridTemplateColumns: {
                          xs: "repeat(2, 1fr)", // 1 column
                          sm: "repeat(2, 1fr)", // 2 columns
                          md: `repeat(${overFlowedColumnsPerRow()}, 1fr)`, // 3 columns
                        },
                        // gap: 2,
                        flexWrap: "wrap",
                        gap: 0.5, // Reduced gap between columns
                        justifyContent: "flexStart",
                        alignItems: "center",
                        borderTop:
                          !isDarkMode && "1px solid rgba(32, 16, 16, 0.12)",
                        border: snapshot.isDraggingOver
                          ? `2px dashed ${isDarkMode ? "#6C63FF" : "#7479ed"}`
                          : isDarkMode && "1px solid rgba(255,255,255,0.1) ",
                        borderRadius: snapshot.isDraggingOver
                          ? "8px"
                          : undefined,

                        transition: "all 0.2s ease",
                        padding: snapshot.isDraggingOver ? "12px" : "2px",
                      }}
                    >
                      {overflowedColumns
                        .filter(
                          (col) =>
                            col &&
                            col.field &&
                            !hiddenColumns.includes(col.field)
                        )
                        .map((col, idx) => (
                          <Draggable
                            key={col.field}
                            draggableId={col.field}
                            index={idx}
                          >
                            {(provided, snapshot) => (
                              <Box
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                sx={{
                                  // flex: "1 1 180px",
                                  background: snapshot.isDragging
                                    ? isDarkMode
                                      ? "rgba(255,255,255,0.1)"
                                      : "rgba(0,0,0,0.1)"
                                    : "transparent",
                                  p: 1,
                                  m: 0.2, // Reduced margin from 0.5 to 0.2 for less gap

                                  whiteSpace: "normal",
                                  maxWidth: calculateOverflowedColumnWidth(
                                    col,
                                    additionalProp?.data || []
                                  ),
                                  minWidth: 120,
                                  display: "flex",
                                  flexDirection: "row",
                                  justifyContent: "flexStart",
                                  // alignItems: "center",
                                  borderRadius: snapshot.isDragging
                                    ? "8px"
                                    : "4px",
                                  boxShadow: snapshot.isDragging
                                    ? "0 4px 12px rgba(0,0,0,0.2)"
                                    : undefined,
                                  cursor: snapshot.isDragging
                                    ? "grabbing"
                                    : "pointer",
                                  transition: "all 0.2s ease",
                                  transform: snapshot.isDragging
                                    ? "rotate(5deg) scale(1.05)"
                                    : "none",
                                  zIndex: snapshot.isDragging ? 1000 : "auto",
                                  opacity: snapshot.isDragging ? 0.8 : 1,
                                }}
                              >
                                <Grow
                                  in={true}
                                  style={{
                                    transformOrigin: "center",
                                    transitionDelay: `${idx * 120}ms`,
                                  }}
                                  timeout={400 + idx * 120}
                                >
                                  <Fade in={true} timeout={400 + idx * 120}>
                                    <Box
                                      sx={{
                                        display: "flex",
                                        flexDirection: "row",
                                        justifyContent: "flexStart",
                                        // alignItems: "center",
                                        // Removed width: "100%" to avoid width conflicts
                                        width: "100%",
                                      }}
                                    >
                                      <Typography
                                        variant="subtitle2"
                                        sx={{
                                          fontWeight:
                                            expanadableRowHeadingTextWeight,
                                          color: expandableRowHeadingColor,
                                          fontSize:
                                            expanadableRowHeadingTextSize,
                                          display: "flex",
                                          flexDirection: "row",
                                          justifyContent: "flexStart",
                                        }}
                                      >
                                        {col.headerName}:
                                      </Typography>
                                      <Typography
                                        variant="body2"
                                        sx={{
                                          color: expanadableRowTextColor,
                                          fontWeight: expanadableRowTextWeight,
                                          fontSize: expanadableRowTextSize,
                                          // textAlign: "center",
                                          ml: 1,
                                          display: "flex",
                                          flexDirection: "row",
                                          justifyContent: "flex-start",

                                          // overflowWrap: "break-word",
                                          wordBreak: "break-word",
                                          // maxWidth: "60%",
                                        }}
                                      >
                                        {GETDisplayValue(
                                          row[col.field],
                                          col.dynamicKey
                                        )}
                                      </Typography>
                                    </Box>
                                  </Fade>
                                </Grow>
                              </Box>
                            )}
                          </Draggable>
                        ))}
                      {provided.placeholder}
                    </Box>
                  )}
                </Droppable>,
                document.body
              );
            })()}
        </DragDropContext>
      ) : enableCollapsibleRow ? (
        <>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              minHeight: "60px",
              background: customHeaderColor,
              color: customHeaderTextColor,
              borderBottom: isDarkMode
                ? "2px solid rgba(255, 255, 255, 0.1)"
                : "2px solid rgba(112, 45, 122,0.4)",
              // width: dataGridRef.current.offsetWidth,
              fontSize: "1rem",
            }}
          >
            {/* Column Headers */}
            <Box
              key="expand-header"
              sx={{
                width: expandColumn.width,
                minWidth: expandColumn.width,
                maxWidth: expandColumn.width,
                // background: customHeaderColor,
                color: customHeaderTextColor,
                fontWeight: "bold",
                display: "flex",
                p: 1,
                alignItems: "flexStart",
                justifyContent: "center",
                borderTopLeftRadius: 0,
                borderTopRightRadius: 0,
                height: 10,
              }}
            >
              <IconButton
                size="medium"
                style={{
                  opacity: 0,
                  width: "80px",
                  height: "100%",
                  background: customHeaderColor,
                }}
              >
                <ArrowRightRoundedIcon />
              </IconButton>
            </Box>

            {orderedVisibleColumns.map((col, index) => (
              <Box
                key={col.field}
                sx={{
                  width: col.width,
                  minWidth: col.width,
                  maxWidth: col.width + "70px",
                  // background: customHeaderColor,
                  color: customHeaderTextColor,
                  fontWeight: "bold",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flexStart",
                  borderTopLeftRadius: index === 0 ? 4 : undefined,
                  height: "auto",
                  cursor: "pointer",
                  position: "relative",
                  "& .sort-icon": {
                    opacity: 0,
                    transition: "opacity 0.2s",
                  },
                  "&:hover .sort-icon": {
                    opacity: 0.5,
                  },
                  "& .sort-icon.sorted": {
                    opacity: 1,
                  },
                }}
                onClick={() => handleColumnSort(col.field)}
              >
                {col.headerName}
                <span
                  className={`sort-icon${
                    sortField === col.field ? " sorted" : ""
                  }`}
                  style={{
                    marginLeft: "3px",
                    marginTop: "2px",
                    color: isDarkMode ? headerTextColor : "black",
                  }}
                >
                  {sortField === col.field ? (
                    sortOrder === "asc" ? (
                      <ArrowUpward fontSize="12px" />
                    ) : sortOrder === "desc" ? (
                      <ArrowDownward fontSize="12px" />
                    ) : (
                      <ArrowUpward fontSize="12px" />
                    )
                  ) : (
                    <SortByAlphaRoundedIcon fontSize="25px" />
                  )}
                </span>
              </Box>
            ))}

            {/* Action Column Header */}
            {shouldShowActionsColumn() && enableRowActions && (
              <Box
                sx={{
                  width: actionColumn.width,
                  minWidth: actionColumn.width,
                  maxWidth: actionColumn.width,
                  // background: "transparent",
                  color: customHeaderTextColor,
                  fontWeight: "bold",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flexStart",
                  borderTopRightRadius: 4,
                  height: "auto",
                  ml: 1,
                }}
              >
                {actionColumn.headerName}
              </Box>
            )}
          </Box>
          {expandedRowId &&
            detailPanelPos &&
            detailPanelPos.height &&
            overflowedColumns.length > 0 &&
            (() => {
              const row = additionalProp?.data?.find(
                (r) => r.id === expandedRowId
              );
              if (!row) return null;
              return ReactDOM.createPortal(
                <Box
                  sx={{
                    background: isDarkMode ? headerBgColor : "#DCDCDC",
                    boxShadow:
                      isDarkMode && "10px 20px 20px rgba(0, 0, 0, 0.3)",
                    position: "absolute",
                    left: detailPanelPos.left,
                    top: detailPanelPos.top,
                    width: detailPanelPos.width,
                    height: detailPanelPos.height,
                    maxWidth: "100vw",
                    display: "grid",
                    gridTemplateColumns: {
                      xs: "repeat(2, 1fr)",
                      sm: "repeat(2, 1fr)",
                      md: `repeat(${overFlowedColumnsPerRow()}, 1fr)`,
                    },
                    gap: 0.5,
                    flexWrap: "wrap",
                    justifyContent: "flexStart",
                    alignItems: "center",
                    borderTop:
                      !isDarkMode && "1px solid rgba(32, 16, 16, 0.12)",
                    border: isDarkMode && "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "0px",
                    transition: "all 0.2s ease",
                    padding: "2px",
                  }}
                >
                  {overflowedColumns
                    .filter(
                      (col) =>
                        col && col.field && !hiddenColumns.includes(col.field)
                    )
                    .map((col, idx) => (
                      <Box
                        key={col.field}
                        sx={{
                          p: 1,
                          m: 0.2,
                          whiteSpace: "normal",
                          maxWidth: calculateOverflowedColumnWidth(
                            col,
                            additionalProp?.data || []
                          ),
                          minWidth: 120,
                          display: "flex",
                          flexDirection: "row",
                          justifyContent: "flexStart",
                        }}
                      >
                        <Grow
                          in={true}
                          style={{
                            transformOrigin: "center",
                            transitionDelay: `${idx * 120}ms`,
                          }}
                          timeout={400 + idx * 120}
                        >
                          <Fade in={true} timeout={400 + idx * 120}>
                            <Box
                              sx={{
                                display: "flex",
                                flexDirection: "row",
                                justifyContent: "flexStart",
                                width: "100%",
                              }}
                            >
                              <Typography
                                variant="subtitle2"
                                sx={{
                                  fontWeight: expanadableRowHeadingTextWeight,
                                  color: expandableRowHeadingColor,
                                  fontSize: expanadableRowHeadingTextSize,
                                }}
                              >
                                {col.headerName}:
                              </Typography>
                              <Typography
                                variant="body2"
                                sx={{
                                  color: expanadableRowTextColor,
                                  fontWeight: expanadableRowTextWeight,
                                  fontSize: expanadableRowTextSize,
                                  ml: 1,
                                  wordBreak: "break-word",
                                }}
                              >
                                {GETDisplayValue(
                                  row[col.field],
                                  col.dynamicKey
                                )}
                              </Typography>
                            </Box>
                          </Fade>
                        </Grow>
                      </Box>
                    ))}
                </Box>,
                document.body
              );
            })()}
        </>
      ) : null}

      {/* Menu component - can be controlled externally or internally */}
      <Menu
        anchorEl={menuAnchorEl}
        open={Boolean(menuAnchorEl)}
        onClose={menuHandleClose}
        sx={{
          position: "absolute",
          mr: 4,
          mt: 1,
          "& .MuiPaper-root": {
            backgroundColor: isDarkMode ? "#1E1E2F" : "#E5E5E5",
            marginRight: "40px",
            maxHeight: "300px",
            border: isDarkMode
              ? "1px solid rgba(255, 255, 255, 0.12)"
              : "1px solid rgba(0, 0, 0, 0.12)",
            borderRadius: "8px",
            boxShadow: isDarkMode
              ? "0 4px 20px rgba(0, 0, 0, 0.3)"
              : "0 4px 20px rgba(0, 0, 0, 0.15)",
          },
          "& .MuiMenuItem-root": {
            color: headerTextColor,
            backgroundColor: "transparent",
            padding: "8px 16px",
            margin: "2px 8px",
            borderRadius: "6px",
            transition: "all 0.2s ease",
            "&:hover": {
              backgroundColor: isDarkMode
                ? "rgba(255, 255, 255, 0.08)"
                : "rgba(0, 0, 0, 0.04)",
              transform: "translateX(2px)",
            },
            "&:active": {
              backgroundColor: isDarkMode
                ? "rgba(255, 255, 255, 0.12)"
                : "rgba(0, 0, 0, 0.08)",
            },
          },
        }}
      >
        {
          <div>
            {allColumns.map((col, index) => (
              <MenuItem
                key={col.field || col.dynamicKey || col.name || index}
                onClick={() => {
                  if (hiddenColumns.includes(col.field)) {
                    handleRestoreColumn(col.field);
                  } else {
                    handleVisibilityClick(col.field);
                  }
                }}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  // background: snapshot.isDragging
                  //   ? isDarkMode
                  //     ? "#23234a"
                  //     : "#d1d1e0"
                  //   : undefined,
                  // boxShadow: snapshot.isDragging
                  //   ? "0 2px 8px rgba(0,0,0,0.15)"
                  //   : undefined,
                }}
              >
                {hiddenColumns.includes(col.field) ? (
                  <VisibilityOffIcon
                    style={{ fontSize: "16px", color: "rgb(216, 23, 23)" }}
                  />
                ) : (
                  <VisibilityIcon style={{ fontSize: "16px" }} />
                )}
                {col.displayName || col.label || "-000"}
              </MenuItem>
            ))}
          </div>
        }
      </Menu>

      {/* Show message when all columns are hidden */}
      {loading || allColumns.length === 0 ? (
        <TableSkeleton />
      ) : allColumns.length > 0 &&
        allColumns.every((col) => hiddenColumns.includes(col.field)) ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "200px",
            border: isDarkMode
              ? "1px solid rgba(255, 255, 255, 0.12)"
              : "1px solid rgba(0, 0, 0, 0.12)",
            borderRadius: "4px",
            backgroundColor: theme.palette.background.paper,
          }}
        >
          <Typography
            variant="h6"
            sx={{
              color: textColor || (isDarkMode ? "#c7c6ff" : "#260143"),
              textAlign: "center",
              transition: "all 0.3s ease",
            }}
          >
            All Columns are hidden by you.
          </Typography>
        </Box>
      ) : (
        <DataGrid
          // rows={sortedRows}
          rows={buildRowsWithDetailPanel(sortedRows)}
          columns={customColumns
            .filter((col) => {
              // Always show 'id' column
              if (col.field === "id") return true;
              // Conditionally include 'expand' and 'actions' fields
              if (col.field === "expand" && !enableCollapsibleRow) return false;
              if (col.field === "actions" && !enableRowActions) return false;
              return (
                col.field === "expand" ||
                col.field === "actions" ||
                (orderedVisibleColumns.some((c) => c.field === col.field) &&
                  !hiddenColumns.includes(col.field))
              );
            })
            .sort((a, b) => {
              // Keep expand first, actions last, others by columnOrder
              if (a.field === "expand") return -1;
              if (b.field === "expand") return 1;
              if (a.field === "actions") return 1;
              if (b.field === "actions") return -1;

              return (
                columnOrder.indexOf(a.field) - columnOrder.indexOf(b.field)
              );
            })
            .map((col) => {
              // Get matching width from orderedVisibleColumns (sync with custom header widths)
              const visibleCol = orderedVisibleColumns.find(
                (c) => c.field === col.field
              );

              return {
                ...col,
                width: visibleCol?.width ?? col.width,
                renderCell: col.renderCell || renderCell,
              };
            })}
          getRowId={(row) => row.id}
          getRowHeight={getRowHeight}
          autoHeight
          pagination
          paginationMode="client"
          disableColumnMenu
          disableVirtualization={false}
          checkboxSelection={checkboxEnabled}
          disableRowSelectionOnClick
          onSelectionModelChange={handleCheckboxChange}
          onRowDoubleClick={handleRowDoubleClick}
          sx={dataGridStyles}

        />
      )}
    </div>
  );
};

export default TableView;
