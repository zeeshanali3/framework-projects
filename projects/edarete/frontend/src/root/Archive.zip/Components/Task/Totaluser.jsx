import React from "react";
import { Box, Typography } from "@mui/material";
import Card from "@mui/material/Card";
// import {TotalUserChart}  from "./Performance/Chart/Totauserchart";

const MilestonesOverview = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Card
        sx={{
          boxShadow: "none",
          borderRadius: "10px",
          p: "25px",
          mb: "15px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #f7f4eeff",
            paddingBottom: "10px",
            mb: "20px",
          }}
          className="for-dark-bottom-border"
        >
          <Typography
            as="h3"
            sx={{
              fontSize: 18,
              fontWeight: 500,
            }}
          >
            Total Users
          </Typography>
        </Box>
            
        {/* <TotalUserChart /> */}

      </Card>
    </>
  );
};

export default MilestonesOverview;
